var bkt=0,passcount=0,load=0,truckload=0,n,target=100;
deactivate_store();
function activate_store()
{
    document.getElementById('store').disabled = false;
}

function deactivate_store()
{
    document.getElementById('store').disabled = true;
}
function addBkt(){
    bkt+=6;
    document.getElementById('Bucket_weight_value').innerHTML = bkt;
    if (bkt>=40){
        activate_store();
        document.getElementById('store').click();
    }
}
function transfer(){
    if (truckload+bkt<=target){
        truckload+=bkt;
        bkt=0;
        passcount+=1;
        document.getElementById('Pass_count_value').innerHTML = passcount;
        document.getElementById('Bucket_weight_value').innerHTML = bkt;
        document.getElementById('Truck_payload_value').innerHTML = truckload;
        deactivate_store();
        if (truckload+bkt==target){
            clearInterval(a);
        }
    } else {
        var temp = truckload+bkt-target;
        truckload = target;
        bkt = temp;
        passcount+=1;
        document.getElementById('Pass_count_value').innerHTML = passcount;
        document.getElementById('Bucket_weight_value').innerHTML = bkt;
        document.getElementById('Truck_payload_value').innerHTML = truckload;
        clearInterval(a);
    }
}

document.getElementById('Pass_count_value').innerHTML = passcount;
document.getElementById('Bucket_weight_value').innerHTML = bkt;
document.getElementById('Truck_payload_value').innerHTML = truckload;
document.getElementById('store').addEventListener('click', transfer)

var a = setInterval(addBkt, 1000)