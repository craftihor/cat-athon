var bkt=0,bkt2,passcount=0,load=0,truckload=0,i=1,target=400;
deactivate_store();
function display()
{
    var tar = document.getElementById('target').value;
    target = tar;
    if(!tar) target = 400;
    document.getElementById('display').innerHTML = target;
    start();
}
function start(){
function activate_store()
{
    document.getElementById('store').disabled = false;
    document.getElementById('sub').disabled = true;
}

function deactivate_store()
{
    document.getElementById('store').disabled = true;
}

function addBkt(){
    bkt+=6;
    document.getElementById('Bucket_weight_value').innerHTML = bkt;
    if (bkt>=40 && bkt<50){
        activate_store();
        stopTimer();
        bkt2=bkt;
        bkt=0;
        document.getElementById("store").click();
    }
}
function transfer(){
    if (truckload+bkt2<=target){
        truckload+=bkt2;
        bkt2=0;
        passcount+=1;
        var table = document.getElementById("tbd");
        var row = table.insertRow(i);
        var cell1 = row.insertCell(0);
        var cell2 = row.insertCell(1);
        var cell3 = row.insertCell(2);
        cell1.innerHTML = i;
        cell2.innerHTML = passcount;
        cell3.innerHTML = truckload;
         i++;  

        document.getElementById('Pass_count_value').innerHTML = passcount;
        document.getElementById('Bucket_weight_value').innerHTML = bkt2;
        document.getElementById('Truck_payload_value').innerHTML = truckload;
        deactivate_store();
        if (truckload+bkt2==target){
            stopTimer();
            deactivate_store();
        }
        startTimer();
    } else {
        var temp = truckload+bkt2-target;
        truckload = target;
        bkt2 = temp;
        passcount+=1;
        document.getElementById('Pass_count_value').innerHTML = passcount;
        document.getElementById('Bucket_weight_value').innerHTML = bkt2;
        document.getElementById('Truck_payload_value').innerHTML = truckload;
        window.alert("The Bucket has some residue of "+bkt2+"Kgs");
        stopTimer();
        deactivate_store();
    }
} 
document.getElementById('Pass_count_value').innerHTML = passcount;
document.getElementById('Bucket_weight_value').innerHTML = bkt;
document.getElementById('Truck_payload_value').innerHTML = truckload;
document.getElementById('store').addEventListener('click', transfer);

let a = setInterval(addBkt, 1000);
function stopTimer()
{
  if (a !== -1) {
    clearInterval(a);
    a = -1; 
  }
}

function startTimer()
{
  if (a === -1) {
    a = setInterval(addBkt, 1000);
  }
}}